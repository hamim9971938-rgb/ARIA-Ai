package com.example.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import com.example.data.Language

data class ActionExecutionResult(
    val cleanText: String,
    val actionExecutedNotice: String? = null
)

class DeviceActionManager(private val context: Context) {

    fun processResponseAndExecute(rawText: String, language: Language): ActionExecutionResult {
        var textToSpeak = rawText
        var actionNotice: String? = null

        val actionRegex = Regex("\\[ACTION:([A-Z_]+)(?::([^]]+))?\\]")
        val matches = actionRegex.findAll(rawText)

        for (match in matches) {
            val actionType = match.groupValues[1]
            val actionArg = match.groupValues.getOrNull(2)

            textToSpeak = textToSpeak.replace(match.value, "").trim()

            when (actionType) {
                "OPEN_APP" -> {
                    val appName = actionArg ?: ""
                    val success = openAppByName(appName)
                    actionNotice = if (success) {
                        when (language) {
                            Language.BANGLA -> "$appName অ্যাপ খোলা হচ্ছে"
                            Language.HINDI -> "$appName ऐप खोला जा रहा है"
                            Language.ENGLISH -> "Opening $appName"
                        }
                    } else {
                        when (language) {
                            Language.BANGLA -> "$appName খুঁজে পাওয়া যায়নি"
                            Language.HINDI -> "$appName नहीं मिला"
                            Language.ENGLISH -> "Could not find $appName"
                        }
                    }
                }
                "OPEN_SETTINGS" -> {
                    val settingType = actionArg?.uppercase() ?: "MAIN"
                    openSystemSettings(settingType)
                    actionNotice = when (language) {
                        Language.BANGLA -> "সেটিংস স্ক্রিন খোলা হয়েছে"
                        Language.HINDI -> "सेटिंग्स स्क्रीन खोली गई"
                        Language.ENGLISH -> "Opened Settings"
                    }
                }
                "TOGGLE_FLASHLIGHT" -> {
                    val enable = actionArg?.uppercase() == "ON"
                    val success = toggleFlashlight(enable)
                    actionNotice = if (success) {
                        when (language) {
                            Language.BANGLA -> if (enable) "ফ্ল্যাশলাইট চালু করা হয়েছে" else "ফ্ল্যাশলাইট বন্ধ করা হয়েছে"
                            Language.HINDI -> if (enable) "फ्लैशलाइट चालू की गई" else "फ्लैशलाइट बंद की गई"
                            Language.ENGLISH -> if (enable) "Flashlight turned ON" else "Flashlight turned OFF"
                        }
                    } else {
                        when (language) {
                            Language.BANGLA -> "ফ্ল্যাশলাইট নিয়ন্ত্রণ করার অনুমতি বা সুবিধা পাওয়া যায়নি"
                            Language.HINDI -> "फ्लैशलाइट नियंत्रण उपलब्ध नहीं है"
                            Language.ENGLISH -> "Flashlight feature unavailable"
                        }
                    }
                }
                "DEVICE_INFO" -> {
                    val info = getDeviceInfoSummary(language)
                    textToSpeak += " $info"
                    actionNotice = when (language) {
                        Language.BANGLA -> "ডিভাইস তথ্য পড়া হয়েছে"
                        Language.HINDI -> "डिवाइस जानकारी पढ़ी गई"
                        Language.ENGLISH -> "Read device information"
                    }
                }
                "SEARCH" -> {
                    val query = actionArg ?: ""
                    searchWeb(query)
                    actionNotice = when (language) {
                        Language.BANGLA -> "ওয়েব অনুসন্ধান করা হচ্ছে: $query"
                        Language.HINDI -> "वेब खोज की जा रही है: $query"
                        Language.ENGLISH -> "Searching web for $query"
                    }
                }
                "ALARM" -> {
                    openAlarmApp()
                    actionNotice = when (language) {
                        Language.BANGLA -> "অ্যালার্ম অ্যাপ খোলা হচ্ছে"
                        Language.HINDI -> "अलार्म ऐप खोला जा रहा है"
                        Language.ENGLISH -> "Opening Alarm"
                    }
                }
            }
        }

        return ActionExecutionResult(
            cleanText = textToSpeak.ifBlank { rawText },
            actionExecutedNotice = actionNotice
        )
    }

    fun openAppByName(appName: String): Boolean {
        val query = appName.trim().lowercase()

        // Handle common shortcuts
        val shortcutIntent = when {
            query.contains("camera") || query.contains("ক্যামেরা") || query.contains("कैमरा") ->
                Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            query.contains("setting") || query.contains("সেটিংস") || query.contains("सेटिंग्स") ->
                Intent(Settings.ACTION_SETTINGS)
            query.contains("phone") || query.contains("dial") || query.contains("ফোন") || query.contains("फोन") ->
                Intent(Intent.ACTION_DIAL)
            query.contains("calc") || query.contains("ক্যালকুলেটর") || query.contains("कैलकुलेटर") -> {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
                if (intent.resolveActivity(context.packageManager) != null) intent else null
            }
            query.contains("gallery") || query.contains("photo") || query.contains("গ্যালারি") -> {
                val intent = Intent(Intent.ACTION_VIEW).setType("image/*")
                if (intent.resolveActivity(context.packageManager) != null) intent else null
            }
            else -> null
        }

        if (shortcutIntent != null) {
            shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try {
                context.startActivity(shortcutIntent)
                true
            } catch (e: Exception) {
                false
            }
        }

        // Search installed apps
        val packageManager = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = packageManager.queryIntentActivities(mainIntent, 0)

        for (info in resolveInfos) {
            val label = info.loadLabel(packageManager).toString().lowercase()
            val packageName = info.activityInfo.packageName
            if (label.contains(query) || packageName.contains(query)) {
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return true
                }
            }
        }
        return false
    }

    fun openSystemSettings(type: String) {
        val action = when (type) {
            "WIFI" -> Settings.ACTION_WIFI_SETTINGS
            "BLUETOOTH" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "DISPLAY" -> Settings.ACTION_DISPLAY_SETTINGS
            "BATTERY" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "SOUND" -> Settings.ACTION_SOUND_SETTINGS
            "ACCESSIBILITY" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "OVERLAY" -> Settings.ACTION_MANAGE_OVERLAY_PERMISSION
            "APP_DETAILS" -> {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }
            else -> Settings.ACTION_SETTINGS
        }

        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleFlashlight(enable: Boolean): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return try {
                val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return false
                cameraManager.setTorchMode(cameraId, enable)
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
        return false
    }

    fun getDeviceInfoSummary(language: Language): String {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level != -1 && scale != -1) (level * 100 / scale.toFloat()).toInt() else -1

        val model = Build.MODEL
        val androidVer = Build.VERSION.RELEASE

        return when (language) {
            Language.BANGLA -> "আপনার ডিভাইস $model, অ্যানড্রয়েড ভার্সন $androidVer এবং চার্জ আছে $batteryPct%।"
            Language.HINDI -> "आपका डिवाइस $model, एंड्रॉइड संस्करण $androidVer और बैटरी $batteryPct% है।"
            Language.ENGLISH -> "Your device is $model running Android $androidVer with $batteryPct% battery."
        }
    }

    fun searchWeb(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun openAlarmApp() {
        val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // fallback to general clock
            openAppByName("clock")
        }
    }
}
