package com.example.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.data.Language
import java.util.Locale

class TextToSpeechManager(
    private val context: Context,
    private val onInitSuccess: () -> Unit = {},
    private val onSpeakingStarted: () -> Unit = {},
    private val onSpeakingFinished: () -> Unit = {}
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupUtteranceListener()
            onInitSuccess()
        }
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                onSpeakingStarted()
            }

            override fun onDone(utteranceId: String?) {
                onSpeakingFinished()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                onSpeakingFinished()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                onSpeakingFinished()
            }
        })
    }

    fun speak(
        text: String,
        language: Language,
        useFemaleVoice: Boolean = true,
        speechRate: Float = 1.0f
    ) {
        if (!isInitialized || tts == null) return

        stop()

        val locale = when (language) {
            Language.BANGLA -> Locale("bn", "BD")
            Language.HINDI -> Locale("hi", "IN")
            Language.ENGLISH -> Locale.US
        }

        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to general locale if BD/IN specific is missing
            val fallbackLocale = when (language) {
                Language.BANGLA -> Locale("bn")
                Language.HINDI -> Locale("hi")
                Language.ENGLISH -> Locale.ENGLISH
            }
            tts?.setLanguage(fallbackLocale)
        }

        // Configure voice properties for female tone
        if (useFemaleVoice) {
            val voices = tts?.voices
            if (!voices.isNullOrEmpty()) {
                val femaleVoice = voices.firstOrNull { voice ->
                    voice.locale.language == locale.language &&
                            (voice.name.lowercase().contains("female") ||
                             voice.name.lowercase().contains("f0") ||
                             voice.name.lowercase().contains("network") ||
                             voice.name.lowercase().contains("c"))
                }
                if (femaleVoice != null) {
                    tts?.voice = femaleVoice
                }
            }
            // Enhance female pitch timbre
            tts?.setPitch(1.22f)
        } else {
            tts?.setPitch(1.0f)
        }

        tts?.setSpeechRate(speechRate.coerceIn(0.5f, 2.0f))

        val utteranceId = "ARIA_UTTERANCE_${System.currentTimeMillis()}"
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        tts = null
        isInitialized = false
    }
}
