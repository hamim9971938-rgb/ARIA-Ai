package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = AriaCyan,
    onPrimary = AriaBackground,
    secondary = AriaMagenta,
    onSecondary = AriaTextPrimary,
    tertiary = AriaPurple,
    background = AriaBackground,
    onBackground = AriaTextPrimary,
    surface = AriaSurface,
    onSurface = AriaTextPrimary,
    surfaceVariant = AriaSurfaceVariant,
    onSurfaceVariant = AriaTextSecondary,
    outline = AriaSurfaceBorder
)

@Composable
fun AriaTheme(
    darkTheme: Boolean = true, // Always default to premium dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
