package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.AssistantState
import com.example.ui.theme.AriaCyan
import com.example.ui.theme.AriaMagenta
import com.example.ui.theme.AriaSpeakingColor

@Composable
fun WaveformView(
    state: AssistantState,
    modifier: Modifier = Modifier
) {
    if (state == AssistantState.IDLE) {
        Canvas(modifier = modifier.fillMaxWidth().height(36.dp)) {
            val centerY = size.height / 2f
            drawLine(
                color = AriaCyan.copy(alpha = 0.2f),
                start = Offset(0f, centerY),
                end = Offset(size.width, centerY),
                strokeWidth = 2f
            )
        }
        return
    }

    val transition = rememberInfiniteTransition(label = "waveform")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val waveColor = when (state) {
        AssistantState.LISTENING -> AriaCyan
        AssistantState.THINKING -> AriaMagenta
        AssistantState.SPEAKING -> AriaSpeakingColor
        else -> AriaCyan
    }

    Canvas(modifier = modifier.fillMaxWidth().height(48.dp)) {
        val barCount = 28
        val spacing = size.width / barCount
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val x = i * spacing + spacing / 2f
            val amplitude = when (state) {
                AssistantState.LISTENING -> (Math.sin(phase + i * 0.4) * 16.dp.toPx()).toFloat().coerceAtLeast(4f)
                AssistantState.THINKING -> (Math.cos(phase * 1.5 + i * 0.3) * 10.dp.toPx()).toFloat().coerceAtLeast(3f)
                AssistantState.SPEAKING -> (Math.sin(phase * 2.0 + i * 0.5) * 20.dp.toPx()).toFloat().coerceAtLeast(6f)
                else -> 2f
            }

            val alpha = (0.4f + kotlin.math.abs(Math.sin(phase.toDouble() + i)) * 0.6f).toFloat()

            drawLine(
                color = waveColor.copy(alpha = alpha),
                start = Offset(x, centerY - kotlin.math.abs(amplitude)),
                end = Offset(x, centerY + kotlin.math.abs(amplitude)),
                strokeWidth = 4.dp.toPx()
            )
        }
    }
}
