package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.AssistantState
import com.example.data.Language
import com.example.ui.components.AriaOrb
import com.example.ui.components.ChatHistoryView
import com.example.ui.components.WaveformView
import com.example.ui.theme.AriaBackground
import com.example.ui.theme.AriaCyan
import com.example.ui.theme.AriaMagenta
import com.example.ui.theme.AriaSurface
import com.example.ui.theme.AriaSurfaceBorder
import com.example.ui.theme.AriaTextPrimary
import com.example.ui.theme.AriaTextSecondary
import com.example.viewmodel.AriaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAssistantScreen(
    viewModel: AriaViewModel,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val currentLanguage by viewModel.selectedLanguage.collectAsState(initial = Language.BANGLA)
    val assistantState by viewModel.assistantState.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val partialSpeechText by viewModel.partialSpeechText.collectAsState()
    val micPermissionGranted by viewModel.micPermissionGranted.collectAsState()

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.checkPermissions()
        if (isGranted) {
            viewModel.startListening()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(AriaCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Aria",
                            color = AriaTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI Voice",
                            color = AriaCyan,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                    }
                },
                actions = {
                    // Language Selector Pills
                    LanguageSelectorBar(
                        selectedLanguage = currentLanguage,
                        onLanguageSelected = { viewModel.setLanguage(it) }
                    )

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = AriaTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AriaBackground
                )
            )
        },
        containerColor = AriaBackground
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {

            // Permission Warning Banner if mic not granted
            if (!micPermissionGranted) {
                Surface(
                    color = AriaMagenta.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AriaMagenta),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable {
                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = AriaMagenta,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Microphone permission needed. Tap to grant.",
                            color = AriaTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Top Hero Space - Orb
            Spacer(modifier = Modifier.height(12.dp))

            AriaOrb(
                state = assistantState,
                language = currentLanguage,
                onOrbClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED
                    ) {
                        if (assistantState == AssistantState.LISTENING) {
                            viewModel.stopListening()
                        } else {
                            viewModel.startListening()
                        }
                    } else {
                        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onStopClick = {
                    viewModel.stopSpeaking()
                }
            )

            // Animated Waveform
            Spacer(modifier = Modifier.height(12.dp))
            WaveformView(
                state = assistantState,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            // Quick Prompt Suggestions Row
            Spacer(modifier = Modifier.height(8.dp))
            QuickActionSuggestionsRow(
                language = currentLanguage,
                onActionSelected = { prompt ->
                    viewModel.processUserSpeech(prompt)
                }
            )

            // Chat History / Responses List
            Spacer(modifier = Modifier.height(8.dp))
            ChatHistoryView(
                messages = chatMessages,
                currentPartialText = partialSpeechText,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )
        }
    }
}

@Composable
fun LanguageSelectorBar(
    selectedLanguage: Language,
    onLanguageSelected: (Language) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .background(AriaSurface, RoundedCornerShape(20.dp))
            .border(1.dp, AriaSurfaceBorder, RoundedCornerShape(20.dp))
            .padding(4.dp)
    ) {
        Language.entries.forEach { lang ->
            val isSelected = lang == selectedLanguage
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isSelected) AriaCyan else Color.Transparent)
                    .clickable { onLanguageSelected(lang) }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = lang.displayName,
                    color = if (isSelected) AriaBackground else AriaTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
fun QuickActionSuggestionsRow(
    language: Language,
    onActionSelected: (String) -> Unit
) {
    val suggestions = when (language) {
        Language.BANGLA -> listOf(
            "ইউটিউব খোলো",
            "একটি গল্প বলো",
            "এখন সময় কত?",
            "সেটিংস খোলো",
            "ফ্ল্যাশলাইট জ্বালাও",
            "ফোন এর তথ্য বলো"
        )
        Language.HINDI -> listOf(
            "यूट्यूब खोलो",
            "कोई कहानी सुनाओ",
            "अभी समय क्या हुआ है?",
            "सेटिंग्स खोलो",
            "फ्लैशलाइट चालू करो",
            "डिवाइस की जानकारी दो"
        )
        Language.ENGLISH -> listOf(
            "Open YouTube",
            "Tell me a story",
            "What time is it?",
            "Open Settings",
            "Turn on flashlight",
            "Device info"
        )
    }

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(suggestions) { prompt ->
            Surface(
                color = AriaSurface,
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AriaSurfaceBorder),
                modifier = Modifier.clickable { onActionSelected(prompt) }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AriaCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = prompt,
                        color = AriaTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
