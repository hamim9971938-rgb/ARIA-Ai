package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AssistantState
import com.example.data.Language
import com.example.ui.theme.AriaCyan
import com.example.ui.theme.AriaMagenta
import com.example.ui.theme.AriaPurple
import com.example.ui.theme.AriaSpeakingColor
import com.example.ui.theme.AriaSurfaceVariant
import com.example.ui.theme.AriaTextPrimary
import com.example.ui.theme.AriaTextSecondary

@Composable
fun AriaOrb(
    state: AssistantState,
    language: Language,
    onOrbClick: () -> Unit,
    onStopClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_animation")

    // Breathing pulse scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Rotation angle for thinking state
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_angle"
    )

    // Wave ring pulse for listening
    val waveRingAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_ring"
    )

    val activeColor = when (state) {
        AssistantState.IDLE -> AriaCyan
        AssistantState.LISTENING -> AriaCyan
        AssistantState.THINKING -> AriaMagenta
        AssistantState.SPEAKING -> AriaSpeakingColor
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(220.dp)
        ) {
            // Background Canvas Aura & Pulsing Rings
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = this.center
                val baseRadius = (size.minDimension / 2f) - 16.dp.toPx()

                if (state == AssistantState.LISTENING) {
                    // Outer expanding radar ring
                    val expandingRadius = baseRadius + (1.0f - waveRingAlpha) * 30.dp.toPx()
                    drawCircle(
                        color = AriaCyan.copy(alpha = waveRingAlpha),
                        radius = expandingRadius,
                        center = center,
                        style = Stroke(width = 3.dp.toPx())
                    )
                }

                if (state == AssistantState.THINKING) {
                    // Rotating particle orbit
                    rotate(rotationAngle, center) {
                        drawCircle(
                            color = AriaMagenta.copy(alpha = 0.6f),
                            radius = baseRadius + 12.dp.toPx(),
                            center = center,
                            style = Stroke(width = 4.dp.toPx())
                        )
                    }
                }

                if (state == AssistantState.SPEAKING) {
                    drawCircle(
                        color = AriaSpeakingColor.copy(alpha = 0.25f * pulseScale),
                        radius = baseRadius + 15.dp.toPx(),
                        center = center
                    )
                }
            }

            // Central Glowing Orb
            val orbScale = if (state == AssistantState.IDLE || state == AssistantState.LISTENING) pulseScale else 1.0f

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(170.dp)
                    .scale(orbScale)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeColor,
                                activeColor.copy(alpha = 0.7f),
                                AriaPurple.copy(alpha = 0.9f),
                                AriaSurfaceVariant
                            )
                        )
                    )
                    .border(
                        width = 3.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(activeColor, Color.White.copy(alpha = 0.8f))
                        ),
                        shape = CircleShape
                    )
                    .testTag("aria_active_orb_button")
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        if (state == AssistantState.SPEAKING) {
                            onStopClick()
                        } else {
                            onOrbClick()
                        }
                    }
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(12.dp)
                ) {
                    when (state) {
                        AssistantState.IDLE -> {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Start Listening",
                                tint = AriaTextPrimary,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ACTIVE",
                                color = AriaTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "TAP TO TALK",
                                color = AriaTextPrimary.copy(alpha = 0.8f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        AssistantState.LISTENING -> {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Listening",
                                tint = AriaTextPrimary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "LISTENING...",
                                color = AriaTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        AssistantState.THINKING -> {
                            Text(
                                text = "ARIA",
                                color = AriaTextPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 3.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "THINKING...",
                                color = AriaTextPrimary.copy(alpha = 0.9f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        AssistantState.SPEAKING -> {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop Speaking",
                                tint = Color.Red,
                                modifier = Modifier.size(46.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "STOP",
                                color = AriaTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Subtitle status label
        val statusText = when (state) {
            AssistantState.IDLE -> when (language) {
                Language.BANGLA -> "কথা বলতে বাটনটি চাপুন"
                Language.HINDI -> "बात करने के लिए बटन दबाएं"
                Language.ENGLISH -> "Tap the orb to start speaking"
            }
            AssistantState.LISTENING -> language.listeningPrompt
            AssistantState.THINKING -> when (language) {
                Language.BANGLA -> "আরিয়া উত্তর তৈরি করছে..."
                Language.HINDI -> "आरिया उत्तर सोच रही है..."
                Language.ENGLISH -> "Aria is processing your request..."
            }
            AssistantState.SPEAKING -> when (language) {
                Language.BANGLA -> "আরিয়া কথা বলছে (থামাতে বাটনে চাপুন)"
                Language.HINDI -> "आरिया बोल रही है (रोकने के लिए दबाएं)"
                Language.ENGLISH -> "Aria is speaking (Tap to cancel)"
            }
        }

        Text(
            text = statusText,
            color = AriaTextSecondary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}
