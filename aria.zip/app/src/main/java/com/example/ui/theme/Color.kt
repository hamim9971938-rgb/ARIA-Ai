package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AriaBackground = Color(0xFF0B0E17)
val AriaSurface = Color(0xFF161B29)
val AriaSurfaceBorder = Color(0xFF2B354D)
val AriaSurfaceVariant = Color(0xFF1E2538)

val AriaCyan = Color(0xFF00F2FE)
val AriaMagenta = Color(0xFFE040FB)
val AriaPurple = Color(0xFF7000FF)
val AriaAccentGreen = Color(0xFF00FF87)
val AriaAccentYellow = Color(0xFFFFD600)

val AriaTextPrimary = Color(0xFFF1F5F9)
val AriaTextSecondary = Color(0xFF94A3B8)
val AriaTextMuted = Color(0xFF64748B)

val AriaListeningColor = Color(0xFF00F2FE)
val AriaThinkingColor = Color(0xFFE040FB)
val AriaSpeakingColor = Color(0xFF00FF87)
