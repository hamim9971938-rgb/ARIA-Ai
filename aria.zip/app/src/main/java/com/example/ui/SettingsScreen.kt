package com.example.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.StopScreenShare
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Language
import com.example.ui.theme.AriaAccentGreen
import com.example.ui.theme.AriaBackground
import com.example.ui.theme.AriaCyan
import com.example.ui.theme.AriaMagenta
import com.example.ui.theme.AriaSurface
import com.example.ui.theme.AriaSurfaceBorder
import com.example.ui.theme.AriaSurfaceVariant
import com.example.ui.theme.AriaTextPrimary
import com.example.ui.theme.AriaTextSecondary
import com.example.viewmodel.AriaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: AriaViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val currentLanguage by viewModel.selectedLanguage.collectAsState(initial = Language.BANGLA)
    val femaleVoiceEnabled by viewModel.femaleVoiceEnabled.collectAsState(initial = true)
    val voiceSpeed by viewModel.voiceSpeed.collectAsState(initial = 1.0f)
    val backgroundAssistantEnabled by viewModel.backgroundServiceEnabled.collectAsState(initial = false)
    val floatingOverlayEnabled by viewModel.floatingOverlayEnabled.collectAsState(initial = false)

    val micGranted by viewModel.micPermissionGranted.collectAsState()
    val overlayGranted by viewModel.overlayPermissionGranted.collectAsState()
    val notificationGranted by viewModel.notificationPermissionGranted.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.checkPermissions()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings & Voice Controls",
                        color = AriaTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = AriaTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AriaBackground
                )
            )
        },
        containerColor = AriaBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Section 1: Language Selection
            SettingsCard(
                title = "Language Selection",
                icon = Icons.Default.Translate
            ) {
                Language.entries.forEach { lang ->
                    val isSelected = lang == currentLanguage
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewModel.setLanguage(lang) }
                            .padding(vertical = 4.dp, horizontal = 8.dp)
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.setLanguage(lang) },
                            colors = RadioButtonDefaults.colors(selectedColor = AriaCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = lang.displayName,
                            color = AriaTextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        if (isSelected) {
                            Text(
                                text = "Active",
                                color = AriaCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Section 2: Female Voice & Speech Speed
            SettingsCard(
                title = "Voice & Speech Settings",
                icon = Icons.Default.Female
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Natural Female Voice",
                            color = AriaTextPrimary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Aria responds in a clear female voice tone",
                            color = AriaTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = femaleVoiceEnabled,
                        onCheckedChange = { viewModel.setFemaleVoice(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AriaCyan, checkedTrackColor = AriaCyan.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Speech Speed: ${String.format("%.1fx", voiceSpeed)}",
                    color = AriaTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = voiceSpeed,
                    onValueChange = { viewModel.setVoiceSpeed(it) },
                    valueRange = 0.5f..1.5f,
                    steps = 9,
                    colors = SliderDefaults.colors(
                        thumbColor = AriaCyan,
                        activeTrackColor = AriaCyan,
                        inactiveTrackColor = AriaSurfaceBorder
                    )
                )
            }

            // Section 3: Assistant Modes (Background & Floating Overlay)
            SettingsCard(
                title = "Assistant Modes & Overlay",
                icon = Icons.Default.RecordVoiceOver
            ) {
                // Background Mode Switch
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Background Assistant Mode",
                            color = AriaTextPrimary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Runs a foreground service with notification for voice access",
                            color = AriaTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = backgroundAssistantEnabled,
                        onCheckedChange = { viewModel.toggleBackgroundService(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AriaCyan, checkedTrackColor = AriaCyan.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Floating Overlay Switch
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Floating Assistant Bubble",
                            color = AriaTextPrimary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Displays a floating tap bubble over other apps",
                            color = AriaTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = floatingOverlayEnabled,
                        onCheckedChange = {
                            if (!overlayGranted && it) {
                                openOverlayPermissionSettings(context)
                            } else {
                                viewModel.toggleFloatingOverlay(it)
                            }
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = AriaCyan, checkedTrackColor = AriaCyan.copy(alpha = 0.3f))
                    )
                }
            }

            // Section 4: Permissions Status Dashboard
            SettingsCard(
                title = "Permissions Dashboard",
                icon = Icons.Default.Security
            ) {
                PermissionStatusRow(
                    title = "Microphone Permission",
                    description = "Required for speech input",
                    isGranted = micGranted,
                    onRequest = {
                        permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                PermissionStatusRow(
                    title = "System Overlay Permission",
                    description = "Required for floating bubble over other apps",
                    isGranted = overlayGranted,
                    onRequest = {
                        openOverlayPermissionSettings(context)
                    }
                )

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Spacer(modifier = Modifier.height(8.dp))
                    PermissionStatusRow(
                        title = "Notifications Permission",
                        description = "Required for background assistant status bar",
                        isGranted = notificationGranted,
                        onRequest = {
                            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                        }
                    )
                }
            }

            // Section 5: Master Stop Control
            Button(
                onClick = { viewModel.stopAllServices() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stop_all_services_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopScreenShare,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Stop All Assistant Services",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Section 6: About Aria & Privacy
            SettingsCard(
                title = "About Aria & Privacy",
                icon = Icons.Default.Info
            ) {
                Text(
                    text = "Aria is a voice-first personal AI assistant built with Gemini AI and Android native speech APIs. Aria respects your privacy:",
                    color = AriaTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Microphone only listens when explicitly requested by user.\n" +
                            "• Conversations are processed securely and not secretly stored.\n" +
                            "• Official Android Intents are used to execute device actions safely.",
                    color = AriaTextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        color = AriaSurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, AriaSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(AriaCyan.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = AriaCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    color = AriaTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun PermissionStatusRow(
    title: String,
    description: String,
    isGranted: Boolean,
    onRequest: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = AriaTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = description,
                color = AriaTextSecondary,
                fontSize = 11.sp
            )
        }

        if (isGranted) {
            Surface(
                color = AriaAccentGreen.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = AriaAccentGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Granted",
                        color = AriaAccentGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            OutlinedButton(
                onClick = onRequest,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AriaCyan),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Grant",
                    color = AriaCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun openOverlayPermissionSettings(context: android.content.Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
