package com.example.data

enum class Language(
    val code: String,
    val displayName: String,
    val localeTag: String,
    val defaultGreeting: String,
    val listeningPrompt: String,
    val failurePrompt: String
) {
    BANGLA(
        code = "bn",
        displayName = "বাংলা",
        localeTag = "bn-BD",
        defaultGreeting = "হ্যালো! আমি আরিয়া। আপনাকে কীভাবে সাহায্য করতে পারি?",
        listeningPrompt = "শুনছি... বলুন",
        failurePrompt = "দুঃখিত, ঠিকমত শুনতে পাইনি। দয়া করে আবার বলুন।"
    ),
    HINDI(
        code = "hi",
        displayName = "हिन्दी",
        localeTag = "hi-IN",
        defaultGreeting = "नमस्ते! मैं आरिया हूँ। मैं आपकी क्या मदद कर सकती हूँ?",
        listeningPrompt = "सुन रही हूँ... बोलिए",
        failurePrompt = "क्षमा करें, मैं सुन नहीं पाई। कृपया पुनः प्रयास करें।"
    ),
    ENGLISH(
        code = "en",
        displayName = "English",
        localeTag = "en-US",
        defaultGreeting = "Hello! I am Aria. How can I assist you today?",
        listeningPrompt = "Listening... speak now",
        failurePrompt = "Sorry, I couldn't catch that. Please try again."
    );

    companion object {
        fun fromCode(code: String): Language {
            return entries.find { it.code == code } ?: BANGLA
        }
    }
}
