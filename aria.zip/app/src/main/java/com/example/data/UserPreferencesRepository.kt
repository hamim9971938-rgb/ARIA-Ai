package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "aria_settings")

class UserPreferencesRepository(private val context: Context) {

    private object PreferenceKeys {
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val FEMALE_VOICE = booleanPreferencesKey("female_voice")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val BACKGROUND_ASSISTANT = booleanPreferencesKey("background_assistant")
        val FLOATING_OVERLAY = booleanPreferencesKey("floating_overlay")
    }

    val languageFlow: Flow<Language> = context.dataStore.data.map { prefs ->
        val code = prefs[PreferenceKeys.LANGUAGE_CODE] ?: Language.BANGLA.code
        Language.fromCode(code)
    }

    val femaleVoiceFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[PreferenceKeys.FEMALE_VOICE] ?: true
    }

    val voiceSpeedFlow: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[PreferenceKeys.VOICE_SPEED] ?: 1.0f
    }

    val backgroundAssistantFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[PreferenceKeys.BACKGROUND_ASSISTANT] ?: false
    }

    val floatingOverlayFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[PreferenceKeys.FLOATING_OVERLAY] ?: false
    }

    suspend fun setLanguage(language: Language) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.LANGUAGE_CODE] = language.code
        }
    }

    suspend fun setFemaleVoice(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.FEMALE_VOICE] = enabled
        }
    }

    suspend fun setVoiceSpeed(speed: Float) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.VOICE_SPEED] = speed
        }
    }

    suspend fun setBackgroundAssistant(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.BACKGROUND_ASSISTANT] = enabled
        }
    }

    suspend fun setFloatingOverlay(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.FLOATING_OVERLAY] = enabled
        }
    }
}
