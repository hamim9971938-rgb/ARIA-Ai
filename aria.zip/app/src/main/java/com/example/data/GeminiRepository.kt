package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class GeminiPart(val text: String)
data class GeminiContent(val role: String? = null, val parts: List<GeminiPart>)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

data class GeminiCandidate(val content: GeminiContent?)
data class GeminiResponse(val candidates: List<GeminiCandidate>?)

class GeminiRepository {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateResponse(
        userPrompt: String,
        language: Language,
        conversationHistory: List<ChatMessage>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext when (language) {
                Language.BANGLA -> "এআই স্টুডিও এর Secret Panel থেকে GEMINI_API_KEY কনফিগার করা হয়নি। দয়া করে কী টি যুক্ত করুন।"
                Language.HINDI -> "एआई स्टूडियो के Secrets Panel में GEMINI_API_KEY कॉन्फ़िगर नहीं है। कृपया API key जोड़ें।"
                Language.ENGLISH -> "GEMINI_API_KEY is missing or not configured in Secrets Panel. Please provide the key."
            }
        }

        val systemPromptText = """
            You are "Aria" (আরিয়া / आरिया), a friendly, intelligent, and natural female voice personal AI assistant on Android.
            The user communicates with you primarily via speech in ${language.displayName} (Language Code: ${language.code}).

            IMPORTANT VOICE ASSISTANT GUIDELINES:
            1. Respond naturally in ${language.displayName}.
            2. Keep responses concise, clear, and direct (1-3 sentences when possible) so that speech synthesis sounds human and pleasant.
            3. Do not use complex markdown symbols, raw URLs, bullet tables, or unpronounceable formatting.
            4. If the user asks for a device command or app action, include the corresponding intent tag at the END of your response in brackets:
               - To open an app: [ACTION:OPEN_APP:AppName] (e.g. YouTube, WhatsApp, Camera, Chrome, Settings, Gallery, Calculator, Phone)
               - To open settings: [ACTION:OPEN_SETTINGS:Type] (e.g. WIFI, BLUETOOTH, DISPLAY, BATTERY, SOUND, MAIN)
               - To toggle flashlight: [ACTION:TOGGLE_FLASHLIGHT:ON] or [ACTION:TOGGLE_FLASHLIGHT:OFF]
               - To get device info: [ACTION:DEVICE_INFO]
               - To set timer/alarm: [ACTION:ALARM]
               - To search web: [ACTION:SEARCH:query]
            5. Always maintain a helpful, warm, and graceful persona.
        """.trimIndent()

        // Build history context (last 6 messages for token efficiency)
        val historyContents = mutableListOf<GeminiContent>()
        val recentHistory = conversationHistory.takeLast(6)
        for (msg in recentHistory) {
            val role = if (msg.isUser) "user" else "model"
            historyContents.add(GeminiContent(role = role, parts = listOf(GeminiPart(msg.text))))
        }
        // Append current prompt
        historyContents.add(GeminiContent(role = "user", parts = listOf(GeminiPart(userPrompt))))

        val requestObj = GeminiRequest(
            contents = historyContents,
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(systemPromptText)))
        )

        try {
            val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
            val requestJson = jsonAdapter.toJson(requestObj)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val body = requestJson.toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                return@withContext when (language) {
                    Language.BANGLA -> "নেটওয়ার্ক বা এপিআই সংক্রান্ত একটি সমস্যা দেখা দিয়েছে।"
                    Language.HINDI -> "नेटवर्क या एपीआई से संबंधित समस्या आई है।"
                    Language.ENGLISH -> "An API or network error occurred."
                }
            }

            val responseBodyString = response.body?.string() ?: ""
            val responseAdapter = moshi.adapter(GeminiResponse::class.java)
            val parsedResponse = responseAdapter.fromJson(responseBodyString)

            val textResult = parsedResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            return@withContext textResult?.trim() ?: when (language) {
                Language.BANGLA -> "দুঃখিত, কোনো উত্তর পাওয়া যায়নি।"
                Language.HINDI -> "क्षमा करें, कोई उत्तर प्राप्त नहीं हुआ।"
                Language.ENGLISH -> "Sorry, no response received."
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext when (language) {
                Language.BANGLA -> "দুঃখিত, কোনো ভুল হয়েছে: ${e.localizedMessage}"
                Language.HINDI -> "क्षमा करें, कोई त्रुटि हुई: ${e.localizedMessage}"
                Language.ENGLISH -> "Error communicating with AI: ${e.localizedMessage}"
            }
        }
    }
}
