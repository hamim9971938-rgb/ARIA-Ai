package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AssistantState
import com.example.data.ChatMessage
import com.example.data.GeminiRepository
import com.example.data.Language
import com.example.data.UserPreferencesRepository
import com.example.device.DeviceActionManager
import com.example.service.AriaForegroundService
import com.example.service.AriaOverlayService
import com.example.speech.SpeechToTextManager
import com.example.speech.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AriaViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val preferencesRepo = UserPreferencesRepository(context)
    private val geminiRepo = GeminiRepository()
    private val deviceActionManager = DeviceActionManager(context)

    // Flows from DataStore
    val selectedLanguage = preferencesRepo.languageFlow
    val femaleVoiceEnabled = preferencesRepo.femaleVoiceFlow
    val voiceSpeed = preferencesRepo.voiceSpeedFlow
    val backgroundServiceEnabled = preferencesRepo.backgroundAssistantFlow
    val floatingOverlayEnabled = preferencesRepo.floatingOverlayFlow

    // UI States
    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _partialSpeechText = MutableStateFlow<String?>(null)
    val partialSpeechText: StateFlow<String?> = _partialSpeechText.asStateFlow()

    private val _micPermissionGranted = MutableStateFlow(false)
    val micPermissionGranted: StateFlow<Boolean> = _micPermissionGranted.asStateFlow()

    private val _overlayPermissionGranted = MutableStateFlow(false)
    val overlayPermissionGranted: StateFlow<Boolean> = _overlayPermissionGranted.asStateFlow()

    private val _notificationPermissionGranted = MutableStateFlow(false)
    val notificationPermissionGranted: StateFlow<Boolean> = _notificationPermissionGranted.asStateFlow()

    private var speechToTextManager: SpeechToTextManager? = null
    private var textToSpeechManager: TextToSpeechManager? = null

    init {
        checkPermissions()
        initTextToSpeech()

        // Set initial welcome greeting in selected language
        viewModelScope.launch {
            val lang = preferencesRepo.languageFlow.first()
            if (_chatMessages.value.isEmpty()) {
                val welcome = ChatMessage(
                    isUser = false,
                    text = lang.defaultGreeting
                )
                _chatMessages.value = listOf(welcome)
            }
        }
    }

    fun checkPermissions() {
        val micGranted = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        _micPermissionGranted.value = micGranted

        val overlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
        _overlayPermissionGranted.value = overlayGranted

        val notificationGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        _notificationPermissionGranted.value = notificationGranted
    }

    private fun initTextToSpeech() {
        textToSpeechManager = TextToSpeechManager(
            context = context,
            onInitSuccess = {},
            onSpeakingStarted = {
                _assistantState.value = AssistantState.SPEAKING
            },
            onSpeakingFinished = {
                if (_assistantState.value == AssistantState.SPEAKING) {
                    _assistantState.value = AssistantState.IDLE
                }
            }
        )
    }

    fun setLanguage(language: Language) {
        viewModelScope.launch {
            preferencesRepo.setLanguage(language)
        }
    }

    fun setFemaleVoice(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepo.setFemaleVoice(enabled)
        }
    }

    fun setVoiceSpeed(speed: Float) {
        viewModelScope.launch {
            preferencesRepo.setVoiceSpeed(speed)
        }
    }

    fun toggleBackgroundService(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepo.setBackgroundAssistant(enabled)
            if (enabled) {
                AriaForegroundService.startService(context)
            } else {
                AriaForegroundService.stopService(context)
            }
        }
    }

    fun toggleFloatingOverlay(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepo.setFloatingOverlay(enabled)
            if (enabled) {
                if (overlayPermissionGranted.value) {
                    AriaOverlayService.startOverlay(context)
                }
            } else {
                AriaOverlayService.stopOverlay(context)
            }
        }
    }

    fun startListening() {
        stopSpeaking()

        if (!micPermissionGranted.value) {
            val msg = "Microphone permission required to speak with Aria."
            addChatMessage(isUser = false, text = msg)
            return
        }

        viewModelScope.launch {
            val currentLang = preferencesRepo.languageFlow.first()

            speechToTextManager?.destroy()
            speechToTextManager = SpeechToTextManager(
                context = context,
                onListeningStarted = {
                    _assistantState.value = AssistantState.LISTENING
                    _partialSpeechText.value = ""
                },
                onPartialText = { text ->
                    _partialSpeechText.value = text
                },
                onResultText = { recognizedText ->
                    _partialSpeechText.value = null
                    processUserSpeech(recognizedText)
                },
                onError = { errorMsg ->
                    _partialSpeechText.value = null
                    _assistantState.value = AssistantState.IDLE
                    addChatMessage(isUser = false, text = errorMsg)
                    speakResponse(errorMsg)
                }
            )

            speechToTextManager?.startListening(currentLang)
        }
    }

    fun stopListening() {
        speechToTextManager?.stopListening()
        _partialSpeechText.value = null
        if (_assistantState.value == AssistantState.LISTENING) {
            _assistantState.value = AssistantState.IDLE
        }
    }

    fun stopSpeaking() {
        textToSpeechManager?.stop()
        if (_assistantState.value == AssistantState.SPEAKING) {
            _assistantState.value = AssistantState.IDLE
        }
    }

    fun stopAllServices() {
        stopListening()
        stopSpeaking()
        AriaForegroundService.stopService(context)
        AriaOverlayService.stopOverlay(context)
        viewModelScope.launch {
            preferencesRepo.setBackgroundAssistant(false)
            preferencesRepo.setFloatingOverlay(false)
        }
    }

    fun processUserSpeech(text: String) {
        if (text.isBlank()) return

        addChatMessage(isUser = true, text = text)
        _assistantState.value = AssistantState.THINKING

        viewModelScope.launch {
            val currentLang = preferencesRepo.languageFlow.first()
            val rawAiResponse = geminiRepo.generateResponse(
                userPrompt = text,
                language = currentLang,
                conversationHistory = _chatMessages.value
            )

            // Execute device actions if detected
            val actionResult = deviceActionManager.processResponseAndExecute(rawAiResponse, currentLang)

            addChatMessage(
                isUser = false,
                text = actionResult.cleanText,
                actionNotice = actionResult.actionExecutedNotice
            )

            speakResponse(actionResult.cleanText)
        }
    }

    private fun speakResponse(text: String) {
        viewModelScope.launch {
            val lang = preferencesRepo.languageFlow.first()
            val useFemale = preferencesRepo.femaleVoiceFlow.first()
            val speed = preferencesRepo.voiceSpeedFlow.first()

            textToSpeechManager?.speak(
                text = text,
                language = lang,
                useFemaleVoice = useFemale,
                speechRate = speed
            )
        }
    }

    private fun addChatMessage(isUser: Boolean, text: String, actionNotice: String? = null) {
        val newMsg = ChatMessage(isUser = isUser, text = text, actionNotice = actionNotice)
        _chatMessages.value = _chatMessages.value + newMsg
    }

    override fun onCleared() {
        super.onCleared()
        speechToTextManager?.destroy()
        textToSpeechManager?.shutdown()
    }
}
